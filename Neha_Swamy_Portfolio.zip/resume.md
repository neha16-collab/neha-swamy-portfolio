# Neha Swamy — Resume (Short)

**Contact**: 201nehanv@gmail.com
**Skills**: SQL, Python, Power BI, Tableau, Excel, DAX, ETL

# Comparative BI — Power BI vs Tableau
- Rebuild the executive KPI dashboard in both tools; add screenshots.

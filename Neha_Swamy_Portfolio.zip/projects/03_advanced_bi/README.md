# Advanced BI — Semantic Model & RLS
- See bi/ and model/ for DAX and security pattern.

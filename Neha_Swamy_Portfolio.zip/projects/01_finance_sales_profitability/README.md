# Finance Sales & Profitability (SQL + Python + Power BI)

See data/, sql/, bi/, notebooks/, screenshots/.

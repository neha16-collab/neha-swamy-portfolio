# Neha Swamy — Data Analyst Portfolio

Power BI · SQL · Python · Excel · Tableau | Finance Analytics & Advanced BI

Projects:
1) Finance Sales & Profitability (SQL + Python + Power BI)
2) Credit Risk & Loan Portfolio (Python + Tableau)
3) Advanced BI — Semantic Model & RLS (Power BI)
4) Comparative BI — Power BI vs Tableau

Contact: 201nehanv@gmail.com
